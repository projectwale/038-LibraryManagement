package com.example.librarymanagement;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class login extends AppCompatActivity {
    TextView txreg, login;
    TextInputLayout ti1, ti2;
    EditText ed1, ed2;
    FirebaseDatabase database;
    DatabaseReference reference;
    public static String Student_userid = "";
    public static String Student_username = "";
    public static String Student_idcardno = "";
    public static String Student_mobileno = "";
    public static String Student_fine = "";
    public static String Student_email = "";
    public static String Student_password = "";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
            if(ContextCompat.checkSelfPermission(login.this, Manifest.permission.POST_NOTIFICATIONS)!= PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(login.this,new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
            }
        }

        txreg = findViewById(R.id.newreg);
        login = findViewById(R.id.log);
        ti1 = findViewById(R.id.username1);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.password1);
        ed2 = ti2.getEditText();

        txreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this, register.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String password = ed2.getText().toString();

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("StudentData");

                if (username.equals("") || password.equals("")) {
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                } else {
                    reference.orderByChild("username").equalTo(username).addListenerForSingleValueEvent(new ValueEventListener() {
                        @SuppressLint("NotificationPermission")
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                    String userkey = userSnapshot.getKey();
                                    Map<String, Object> userData = (Map<String, Object>) userSnapshot.getValue();

                                    if (userData != null && userData.containsKey("password") && userData.get("password").equals(password)) {
                                        Student_userid = userkey;
                                        Student_username = username;
                                        Student_idcardno = userData.get("library").toString();
                                        Student_mobileno = userData.get("mobile").toString();
                                        Student_fine = userData.get("fine").toString();
                                        Student_email = userData.get("email").toString();
                                        Student_password = userData.get("password").toString();

                                        SharedPreferences sh = getSharedPreferences("MySharedPref" + Student_userid, MODE_PRIVATE);
                                        int a = sh.getInt("fine", 0);

                                        if (Integer.parseInt(Student_fine) != a) {

                                            makeNotification(Student_fine);

                                            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref"+Student_userid, MODE_PRIVATE);
                                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                                            myEdit.putInt("fine", Integer.parseInt(Student_fine));
                                            myEdit.apply();
                                        }

                                        Intent intent = new Intent(login.this, MainActivity.class);
                                        startActivity(intent);
                                        finish(); // Optional: Close the login activity to prevent going back
                                    } else {
                                        Snackbar.make(v, "Incorrect password !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                    }
                                }
                            } else {
                                Snackbar.make(v, "Username not found !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Snackbar.make(v, "Something went wrong !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        }
                    });
                }
            }
        });
    }

    public void makeNotification(String fine){
        String chid = "channalid";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),chid);
        builder.setSmallIcon(R.drawable.logo)
            .setContentTitle("Fine alert")
            .setContentText("Your fine is updated ! Fine is : "+fine)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(),0,i,PendingIntent.FLAG_MUTABLE);

        builder.setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            NotificationChannel notificationChannel = notificationManager.getNotificationChannel(chid);
            if(notificationChannel == null){
                int importance = NotificationManager.IMPORTANCE_HIGH;
                notificationChannel = new NotificationChannel(chid,"Some",importance);
                notificationChannel.setLightColor(Color.GREEN);

                notificationChannel.enableVibration(true);
                notificationManager.createNotificationChannel(notificationChannel);

            }
        }

        notificationManager.notify(0,builder.build());

    }
}