package com.example.librarymanagement;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class register extends AppCompatActivity {
    TextView reg;
    TextInputLayout ti1,ti2,ti3,ti4,ti5;
    EditText ed1,ed2,ed3,ed4,ed5;
    FirebaseDatabase database;
    DatabaseReference reference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

//        getSupportActionBar().hide();

        reg = findViewById(R.id.txreg);
        ti1 = findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.email);
        ed2 = ti2.getEditText();
        ti3 = findViewById(R.id.mobile);
        ed3 = ti3.getEditText();
        ti4 = findViewById(R.id.password);
        ed4 = ti4.getEditText();
        ti5 = findViewById(R.id.librarycard);
        ed5 = ti5.getEditText();

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                String library = ed5.getText().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("StudentData");

                if(username.equals("") || email.equals("")|| mobile.equals("")|| password.equals("")|| library.equals("")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    reference.orderByChild("username").equalTo(username).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                Snackbar.make(v, "Username already exists!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                            } else {
                                FirebaseInstanceId.getInstance().getInstanceId()
                                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                                if(task.isSuccessful()) {

                                                    String token =task.getResult().getToken();
                                                    Map<String, Object> userData = new HashMap<>();
                                                    userData.put("username", username);
                                                    userData.put("email", email);
                                                    userData.put("mobile", mobile);
                                                    userData.put("password", password);
                                                    userData.put("library", library);
                                                    userData.put("token", token);
                                                    userData.put("fine", "0");

                                                    reference.push().setValue(userData);

                                                    Snackbar.make(v, "You have signed up successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();

                                                    Intent intent = new Intent(register.this, login.class);
                                                    startActivity(intent);

                                                }
                                                else{
                                                    Toast.makeText(register.this, "Token genration failed", Toast.LENGTH_SHORT).show();
                                                }

                                            }
                                        });
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Snackbar.make(v, "Something went wrong !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        }
                    });
                }
            }
        });

    }
}