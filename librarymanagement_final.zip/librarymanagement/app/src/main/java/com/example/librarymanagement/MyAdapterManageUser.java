package com.example.librarymanagement;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MyAdapterManageUser extends RecyclerView.Adapter<MyViewHolderManageUser> {

    private Context context;
    private List<User> dataList;
    DatabaseReference databaseReference;
    public MyAdapterManageUser(Context context, List<User> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolderManageUser onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, parent, false);
        return new MyViewHolderManageUser(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderManageUser holder, int position) {
        holder.recTitle.setText(dataList.get(position).getLibrary());
        holder.recCategory.setText(dataList.get(position).getEmail());
        holder.recRating.setText("+91 "+dataList.get(position).getMobile());

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateUser.class);
                intent.putExtra("docid", dataList.get(holder.getAdapterPosition()).getDocumentid());
                intent.putExtra("username", dataList.get(holder.getAdapterPosition()).getUsername());
                intent.putExtra("email", dataList.get(holder.getAdapterPosition()).getEmail());
                intent.putExtra("mobile", dataList.get(holder.getAdapterPosition()).getMobile());
                intent.putExtra("password", dataList.get(holder.getAdapterPosition()).getPassword());
                intent.putExtra("cardno", dataList.get(holder.getAdapterPosition()).getLibrary());
                context.startActivity(intent);
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Action");
                builder.setMessage("Are you sure want to delete?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFirebaseFromId(dataList.get(holder.getAdapterPosition()).getDocumentid());
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
    }

    private void deleteFirebaseFromId(String dockey){
        databaseReference = FirebaseDatabase.getInstance().getReference("StudentData").child(dockey);
        databaseReference.removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "User deleted successfully!", Snackbar.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<User> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolderManageUser extends RecyclerView.ViewHolder{

    ImageView recImage,edit,delete;
    TextView recTitle,recCategory,recRating;
    CardView recCard;

    public MyViewHolderManageUser(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recRating = itemView.findViewById(R.id.rating);
        edit = itemView.findViewById(R.id.edit);
        delete = itemView.findViewById(R.id.delete);
    }
}