package com.example.librarymanagement;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.List;

public class MyAdapterPaidFine extends RecyclerView.Adapter<MyViewHolderPaidFine> {

    private Context context;
    private List<User> dataList;
    DatabaseReference databaseReference;
    public MyAdapterPaidFine(Context context, List<User> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolderPaidFine onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item4, parent, false);
        return new MyViewHolderPaidFine(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderPaidFine holder, int position) {
        holder.recTitle.setText(dataList.get(position).getLibrary());
        holder.recCategory.setText(dataList.get(position).getEmail());
        holder.recRating.setText("Rs. :"+dataList.get(position).getFine());
        holder.recTranid.setText("Tranaction :"+dataList.get(position).getDocumentid());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<User> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolderPaidFine extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle,recCategory,recRating,recTranid;
    CardView recCard;

    public MyViewHolderPaidFine(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recRating = itemView.findViewById(R.id.rating);
        recTranid = itemView.findViewById(R.id.tranid);
    }
}