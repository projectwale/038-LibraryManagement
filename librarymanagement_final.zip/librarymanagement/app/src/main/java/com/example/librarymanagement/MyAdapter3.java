package com.example.librarymanagement;

import static com.example.librarymanagement.login.Student_fine;
import static com.example.librarymanagement.login.Student_idcardno;
import static com.example.librarymanagement.login.Student_mobileno;
import static com.example.librarymanagement.login.Student_userid;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MyAdapter3 extends RecyclerView.Adapter<MyViewHolder3> {

    private Context context;
    private List<DataClass> dataList;
    DatabaseReference databaseReference,databaseReference1,reference;
    public MyAdapter3(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder3 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item3, parent, false);
        return new MyViewHolder3(view);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder3 holder, int position) {
        Glide.with(context).load(dataList.get(position).getBookimg()).into(holder.recImage);
        holder.recTitle.setText("Title : "+dataList.get(position).getBooktitle().toUpperCase());
        holder.recCategory.setText("Category : "+dataList.get(position).getBookcat());
        holder.recRating.setText("Valid till : "+dataList.get(position).getIssuedate());

        databaseReference = FirebaseDatabase.getInstance().getReference("IssuedBooks");
        databaseReference1 = FirebaseDatabase.getInstance().getReference("StudentData");
        reference = FirebaseDatabase.getInstance().getReference("ReturnBookData");

        String returnDate = dataList.get(position).getIssuedate();
        String currentDateStr = getCurrentDate();

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date inputDateObj = dateFormat.parse(returnDate);
            Date currentDateObj = dateFormat.parse(currentDateStr);
            long timeDifferenceInMillis = inputDateObj.getTime() - currentDateObj.getTime();
            long hoursDifference = timeDifferenceInMillis / (60 * 60 * 1000);
            System.out.println("Time difference: " + hoursDifference + " hours");

            if(hoursDifference < 24){
                holder.issue.setVisibility(TextView.VISIBLE);
                holder.returnbook.setVisibility(TextView.VISIBLE);
            }else {
                holder.issue.setVisibility(TextView.GONE);
                holder.returnbook.setVisibility(TextView.GONE);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.issue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String returnDate = dataList.get(position).getIssuedate();
                String currentDateStr = getCurrentDate();

                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date inputDateObj = dateFormat.parse(returnDate);
                    Date currentDateObj = dateFormat.parse(currentDateStr);
                    long timeDifferenceInMillis = inputDateObj.getTime() - currentDateObj.getTime();
                    long hoursDifference = timeDifferenceInMillis / (60 * 60 * 1000);
                    System.out.println("Time difference: " + hoursDifference + " hours");

                    if(hoursDifference < 0){

                        int CalculatedFine = (Math.abs((int)hoursDifference) * 5);

                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Fine Alert");
                        builder.setMessage("Your calculated fine is "+CalculatedFine+".");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        DatabaseReference UserRef = databaseReference1.child(Student_userid);
                                        UserRef.child("fine").setValue(String.valueOf(CalculatedFine+Integer.parseInt(Student_fine)));

                                        Student_fine = String.valueOf(CalculatedFine+Integer.parseInt(Student_fine));
                                        DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                                        bookRef.child("returndate").setValue("");
                                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Request send for Re-Issue !", Snackbar.LENGTH_SHORT).show();

                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }else {
                        DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                        bookRef.child("returndate").setValue("");
                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Request send for Re-Issue !", Snackbar.LENGTH_SHORT).show();

                        notifyDataSetChanged();
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });

        holder.returnbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String returnDate = dataList.get(position).getIssuedate();
                String currentDateStr = getCurrentDate();

                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date inputDateObj = dateFormat.parse(returnDate);
                    Date currentDateObj = dateFormat.parse(currentDateStr);
                    long timeDifferenceInMillis = inputDateObj.getTime() - currentDateObj.getTime();
                    long hoursDifference = timeDifferenceInMillis / (60 * 60 * 1000);
                    System.out.println("Time difference: " + hoursDifference + " hours");

                    if(hoursDifference < 0){

                        int CalculatedFine = (Math.abs((int)hoursDifference) * 5);

                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Fine Alert");
                        builder.setMessage("Your calculated fine is "+CalculatedFine+".");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        DatabaseReference UserRef = databaseReference1.child(Student_userid);
                                        UserRef.child("fine").setValue(String.valueOf(CalculatedFine+Integer.parseInt(Student_fine)));

                                        Map<String, Object> returnBookData = new HashMap<>();
                                        returnBookData.put("bookimg", dataList.get(position).getBookimg());
                                        returnBookData.put("title", dataList.get(position).getBooktitle());
                                        returnBookData.put("category", dataList.get(position).getBookcat());
                                        returnBookData.put("returndate", getCurrentDate());
                                        returnBookData.put("cardno", Student_idcardno);
                                        returnBookData.put("mobileno", Student_mobileno);
                                        returnBookData.put("uploderid", dataList.get(position).getUploaderid());
                                        reference.push().setValue(returnBookData);

                                        DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                                        bookRef.removeValue()
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {
                                                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Book retured Sucessfully !", Snackbar.LENGTH_SHORT).show();
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                                                    }
                                                });

                                        notifyDataSetChanged();
                                        dialog.dismiss();
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }else {

                        Map<String, Object> returnBookData = new HashMap<>();
                        returnBookData.put("bookimg", dataList.get(position).getBookimg());
                        returnBookData.put("title", dataList.get(position).getBooktitle());
                        returnBookData.put("category", dataList.get(position).getBookcat());
                        returnBookData.put("returndate", getCurrentDate());
                        returnBookData.put("cardno", Student_idcardno);
                        returnBookData.put("mobileno", Student_mobileno);
                        returnBookData.put("uploderid", dataList.get(position).getUploaderid());
                        reference.push().setValue(returnBookData);

                        DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                        bookRef.removeValue()
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Book retured Sucessfully !", Snackbar.LENGTH_SHORT).show();
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                                    }
                                });

                        notifyDataSetChanged();
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }

    private String getCurrentDate() {
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(currentDate);
    }

}

class MyViewHolder3 extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle,recCategory,recRating,issue,returnbook;
    CardView recCard;

    public MyViewHolder3(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recRating = itemView.findViewById(R.id.rating);
        issue = itemView.findViewById(R.id.issue);
        returnbook = itemView.findViewById(R.id.returnbook);

        recRating.setTextColor(Color.parseColor("#B1352C"));
        recRating.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);

    }
}

