package com.example.librarymanagement;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter4 extends RecyclerView.Adapter<MyViewHolder4> {

    private Context context;
    private List<DataClass> dataList;
    DatabaseReference databaseReference;
    public MyAdapter4(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder4 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item2, parent, false);
        return new MyViewHolder4(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder4 holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(dataList.get(position).getBookimg()).into(holder.recImage);
        holder.recTitle.setText(dataList.get(position).getBooktitle().toUpperCase());
        holder.recCategory.setText(dataList.get(position).getBookcat());
        holder.recCardno.setText("Library Card no. : "+dataList.get(position).getCardno());
        holder.recMobile.setText("Mobile : "+dataList.get(position).getMobile());

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }

}


class MyViewHolder4 extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle,recCategory,recCardno,recMobile;
    CardView recCard;
    LinearLayout lin;

    public MyViewHolder4(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recCardno = itemView.findViewById(R.id.cardno);
        recMobile = itemView.findViewById(R.id.mobile);
        lin = itemView.findViewById(R.id.lin1);

        lin.setVisibility(View.GONE);
    }
}

