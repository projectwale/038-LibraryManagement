package com.example.librarymanagement;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MyAdapter2 extends RecyclerView.Adapter<MyViewHolder2> {

    private Context context;
    private List<DataClass> dataList;
    DatabaseReference databaseReference;
    public MyAdapter2(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item2, parent, false);
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, @SuppressLint("RecyclerView") int position) {
        Glide.with(context).load(dataList.get(position).getBookimg()).into(holder.recImage);
        holder.recTitle.setText(dataList.get(position).getBooktitle().toUpperCase());
        holder.recCategory.setText(dataList.get(position).getBookcat());
        holder.recCardno.setText("Library Card no. : "+dataList.get(position).getCardno());
        holder.recMobile.setText("Mobile : "+dataList.get(position).getMobile());

        databaseReference = FirebaseDatabase.getInstance().getReference("IssuedBooks");

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                int daysToAdd = 7;
                String resultDate = addDaysToDate(dataList.get(position).getIssuedate(), daysToAdd);
                bookRef.child("returndate").setValue(resultDate);
                Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Request accepted !", Snackbar.LENGTH_SHORT).show();

                notifyDataSetChanged();
            }
        });

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference bookRef = databaseReference.child(dataList.get(position).getDocumentid());
                bookRef.removeValue()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Request rejected !", Snackbar.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                            }
                        });

                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }

    public static String addDaysToDate(String inputDate, int daysToAdd) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        try {
            Date date = sdf.parse(inputDate);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_MONTH, daysToAdd);
            String resultDate = sdf.format(calendar.getTime());
            return resultDate;
        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Handle the parse exception as needed
        }
    }
}


class MyViewHolder2 extends RecyclerView.ViewHolder{

    ImageView recImage;
    TextView recTitle,recCategory,recCardno,accept,reject,recMobile;
    CardView recCard;

    public MyViewHolder2(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recCardno = itemView.findViewById(R.id.cardno);
        recMobile = itemView.findViewById(R.id.mobile);
        accept = itemView.findViewById(R.id.acc);
        reject = itemView.findViewById(R.id.rej);
    }
}

