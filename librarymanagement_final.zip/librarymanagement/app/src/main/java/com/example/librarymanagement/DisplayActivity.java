package com.example.librarymanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.Arrays;

public class DisplayActivity extends AppCompatActivity {

    TextView title,category,rating,description,id;
    ImageView image;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Book details");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        image = findViewById(R.id.imageView2);
        title = findViewById(R.id.title);
        category = findViewById(R.id.category);
        rating = findViewById(R.id.rating);
        description = findViewById(R.id.description);
        id = findViewById(R.id.idofdes);

        title.setText(getIntent().getStringExtra("booktitle"));
        rating.setText("Rating : "+getIntent().getStringExtra("bookrating")+" / 5");
        description.setText(getIntent().getStringExtra("bookdesc"));
        id.setText("Description (id - "+getIntent().getStringExtra("bookid")+")");

        Glide.with(this)
                .load(getIntent().getStringExtra("bookimg"))
                .apply(new RequestOptions()
                        .placeholder(R.drawable.preview) // Optional placeholder image while loading
                        .error(R.drawable.preview) // Optional error image if the download fails
                        .diskCacheStrategy(DiskCacheStrategy.ALL))
                .into(image);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}