package com.example.librarymanagement.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.librarymanagement.MyAdapterPaidFine;
import com.example.librarymanagement.R;
import com.example.librarymanagement.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ViewPaidFine extends Fragment {

    DatabaseReference databaseReference;
    RecyclerView recyclerView;
    List<User> dataList;
    MyAdapterPaidFine adapter;
    SearchView searchView;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_view_paid_fine, container, false);

        recyclerView = root.findViewById(R.id.recyclerView);
        searchView = root.findViewById(R.id.search_input);
        searchView.clearFocus();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        dataList = new ArrayList<>();
        ArrayList<User> maindataList = new ArrayList<>();
        adapter = new MyAdapterPaidFine(getActivity(), dataList);
        recyclerView.setAdapter(adapter);
        searchView.setQuery("", false);
        databaseReference = FirebaseDatabase.getInstance().getReference("CollectedFine");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                maindataList.clear();
                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    User dataClass = new User();
//                    String userkey =  itemSnapshot.getKey();
                    Map<String, Object> userData = (Map<String, Object>) itemSnapshot.getValue();

                    dataClass.setLibrary(userData.get("library").toString());
                    dataClass.setEmail(userData.get("email").toString());
                    dataClass.setFine(userData.get("amount").toString());
                    dataClass.setDocumentid(userData.get("transactionid").toString());

                    dataList.add(dataClass);
                    maindataList.add(dataClass);
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                if(!newText.equals("")){
                    searchList(newText);
                }
                else {
                    adapter.searchDataList(maindataList);
                }
                return true;
            }
        });

        return root;
    }

    public void searchList(String text){
        ArrayList<User> searchList = new ArrayList<>();
        for (User dataClass: dataList){
            if (dataClass.getLibrary().toLowerCase().contains(text.toLowerCase())){
                searchList.add(dataClass);
            }
        }
        adapter.searchDataList(searchList);
    }
}