package com.example.librarymanagement;

import static com.example.librarymanagement.login.Student_idcardno;
import static com.example.librarymanagement.login.Student_mobileno;
import static com.example.librarymanagement.login.Student_userid;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class DisplayActivity1 extends AppCompatActivity {

    TextView title,category,rating,description,id,issue;
    ImageView image;
    FirebaseDatabase database;
    DatabaseReference reference;

    private boolean existFlag = true;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            SpannableString spannableString = new SpannableString("Issue Book");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        image = findViewById(R.id.imageView2);
        title = findViewById(R.id.title);
        category = findViewById(R.id.category);
        rating = findViewById(R.id.rating);
        description = findViewById(R.id.description);
        id = findViewById(R.id.idofdes);
        issue = findViewById(R.id.issue);

        title.setText(getIntent().getStringExtra("booktitle"));
        rating.setText("Rating : "+getIntent().getStringExtra("bookrating")+" / 5");
        description.setText(getIntent().getStringExtra("bookdesc"));
        id.setText("Description (id - "+getIntent().getStringExtra("bookid")+")");

        Glide.with(this)
                .load(getIntent().getStringExtra("bookimg"))
                .apply(new RequestOptions()
                        .placeholder(R.drawable.preview) // Optional placeholder image while loading
                        .error(R.drawable.preview) // Optional error image if the download fails
                        .diskCacheStrategy(DiskCacheStrategy.ALL))
                .into(image);

        database = FirebaseDatabase.getInstance();
        reference = database.getReference("IssuedBooks");

        issue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    reference.orderByChild("studentid").equalTo(Student_userid).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (DataSnapshot bookSnapshot : dataSnapshot.getChildren()) {
                                    Map<String, Object> bookData = (Map<String, Object>) bookSnapshot.getValue();
                                    if (bookData != null && bookData.get("bookid").equals(getIntent().getStringExtra("documentid"))) {
                                        existFlag=false;
                                    }
                                }
                                if(existFlag){
                                    Map<String, Object> userData = new HashMap<>();
                                    userData.put("studentid", Student_userid);
                                    userData.put("bookid", getIntent().getStringExtra("documentid"));
                                    userData.put("issuedate", getCurrentDate());
                                    userData.put("returndate","");
                                    userData.put("uploaderid",getIntent().getStringExtra("uploaderid"));
                                    userData.put("library",Student_idcardno);
                                    userData.put("mobile",Student_mobileno);

                                    DatabaseReference newEntryRef = reference.push();
                                    newEntryRef.setValue(userData);
                                    String documentId = newEntryRef.getKey();

                                    Snackbar.make(v, "Request send successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                }
                                else {
                                    Snackbar.make(v, "This book is already owned by you. Check your book list.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                }
                            }
                            else {
                                Map<String, Object> userData = new HashMap<>();
                                userData.put("studentid", Student_userid);
                                userData.put("bookid", getIntent().getStringExtra("documentid"));
                                userData.put("issuedate", getCurrentDate());
                                userData.put("returndate","");
                                userData.put("uploaderid",getIntent().getStringExtra("uploaderid"));
                                userData.put("library",Student_idcardno);
                                userData.put("mobile",Student_mobileno);

                                DatabaseReference newEntryRef = reference.push();
                                newEntryRef.setValue(userData);
                                String documentId = newEntryRef.getKey();

                                Snackbar.make(v, "Request send successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Snackbar.make(v, "Something went wrong !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        }
                    });
            }
        });
    }

    private String getCurrentDate() {
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(currentDate);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}