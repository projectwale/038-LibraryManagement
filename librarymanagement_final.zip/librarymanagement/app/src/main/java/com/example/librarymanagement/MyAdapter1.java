package com.example.librarymanagement;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.librarymanagement.ui.UpdateBook;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter1 extends RecyclerView.Adapter<MyViewHolder1> {

    private Context context;
    private List<DataClass> dataList;
    DatabaseReference databaseReference;
    public MyAdapter1(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item1, parent, false);
        return new MyViewHolder1(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder1 holder, int position) {
        Glide.with(context).load(dataList.get(position).getBookimg()).into(holder.recImage);
        holder.recTitle.setText("Title : "+dataList.get(position).getBooktitle().toUpperCase());
        holder.recCategory.setText("Category : "+dataList.get(position).getBookcat());
        holder.recRating.setText("Rating : "+dataList.get(position).getBookrating()+" / 5");

        holder.recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DisplayActivity1.class);
                intent.putExtra("bookid", dataList.get(holder.getAdapterPosition()).getBookid());
                intent.putExtra("booktitle", dataList.get(holder.getAdapterPosition()).getBooktitle());
                intent.putExtra("bookcat", dataList.get(holder.getAdapterPosition()).getBookcat());
                intent.putExtra("bookrating", dataList.get(holder.getAdapterPosition()).getBookrating());
                intent.putExtra("bookdesc", dataList.get(holder.getAdapterPosition()).getBookdesc());
                intent.putExtra("bookimg", dataList.get(holder.getAdapterPosition()).getBookimg());
                intent.putExtra("uploaderid", dataList.get(holder.getAdapterPosition()).getUploaderid());
                intent.putExtra("uploader", dataList.get(holder.getAdapterPosition()).getUploader());
                intent.putExtra("documentid", dataList.get(holder.getAdapterPosition()).getDocumentid());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}


class MyViewHolder1 extends RecyclerView.ViewHolder{

    ImageView recImage,edit,delete;
    TextView recTitle,recCategory,recRating;
    CardView recCard;

    public MyViewHolder1(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recRating = itemView.findViewById(R.id.rating);
    }
}

