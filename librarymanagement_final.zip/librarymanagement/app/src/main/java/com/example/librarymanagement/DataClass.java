package com.example.librarymanagement;

public class DataClass {

    private String bookid;
    private String booktitle;
    private String bookcat;
    private String bookrating;
    private String bookdesc;
    private String bookimg;
    private String uploaderid;
    private String uploader;
    private String documentid;
    private String cardno;
    private String mobile;
    private String issuedate;

    public DataClass(String bookid, String booktitle, String bookcat, String bookrating, String bookdesc, String bookimg, String uploaderid, String uploader) {
        this.bookid = bookid;
        this.booktitle = booktitle;
        this.bookcat = bookcat;
        this.bookrating = bookrating;
        this.bookdesc = bookdesc;
        this.bookimg = bookimg;
        this.uploaderid = uploaderid;
        this.uploader = uploader;
    }

    public DataClass() {

    }

    public void setAdditionalInfo(String additionalKey, String additionalValue) {
        // Set additional key-value pair here
    }

    // Getter methods
    public String getBookid() {
        return bookid;
    }

    public String getDocumentid() {
        return documentid;
    }

    public String getBooktitle() {
        return booktitle;
    }

    public String getBookcat() {
        return bookcat;
    }

    public String getBookrating() {
        return bookrating;
    }

    public String getBookdesc() {
        return bookdesc;
    }

    public String getBookimg() {
        return bookimg;
    }

    public String getUploaderid() {
        return uploaderid;
    }

    public String getUploader() {
        return uploader;
    }
    public String getCardno() {
        return cardno;
    }
    public String getMobile() {
        return mobile;
    }

    public String getIssuedate() {
        return issuedate;
    }

    // Setter methods
    public void setBookid(String bookid) {
        this.bookid = bookid;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public void setBookcat(String bookcat) {
        this.bookcat = bookcat;
    }

    public void setBookrating(String bookrating) {
        this.bookrating = bookrating;
    }

    public void setBookdesc(String bookdesc) {
        this.bookdesc = bookdesc;
    }

    public void setBookimg(String bookimg) {
        this.bookimg = bookimg;
    }

    public void setUploaderid(String uploaderid) {
        this.uploaderid = uploaderid;
    }

    public void setUploader(String uploader) {
        this.uploader = uploader;
    }

    public void setDocumentid(String documentid) {
        this.documentid = documentid;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setIssuedate(String issuedate) {
        this.issuedate = issuedate;
    }
}
