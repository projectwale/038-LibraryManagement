package com.example.librarymanagement;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SelectLogin extends AppCompatActivity {

    DatabaseReference databaseReference;
    TextView tx1,tx2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_login);

        tx1 = findViewById(R.id.student);
        tx2 = findViewById(R.id.librarian);

        databaseReference = FirebaseDatabase.getInstance().getReference().child("Books");

        tx1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        long count = dataSnapshot.getChildrenCount();
                        Log.d("TAG", "Number of data: " + count);

                        SharedPreferences sh = getSharedPreferences("BookPref", MODE_PRIVATE);
                        int a = sh.getInt("nobook", 0);

                        if ((int)count > a) {

                            makeNotification(String.valueOf((int)count-a));

                            SharedPreferences sharedPreferences = getSharedPreferences("BookPref", MODE_PRIVATE);
                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            myEdit.putInt("nobook", (int)count);
                            myEdit.apply();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.d("TAG", "Database Error: " + databaseError.getMessage());
                    }
                });

                startActivity(new Intent(SelectLogin.this,login.class));
            }
        });

        tx2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SelectLogin.this,LibrarianLogin.class));
            }
        });
    }


    public void makeNotification(String no){
        String chid = "channalid";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),chid);
        builder.setSmallIcon(R.drawable.logo)
                .setContentTitle("Books alert")
                .setContentText(no+" New book is added !")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(),0,i,PendingIntent.FLAG_MUTABLE);

        builder.setContentIntent(pendingIntent);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            NotificationChannel notificationChannel = notificationManager.getNotificationChannel(chid);
            if(notificationChannel == null){
                int importance = NotificationManager.IMPORTANCE_HIGH;
                notificationChannel = new NotificationChannel(chid,"Some",importance);
                notificationChannel.setLightColor(Color.GREEN);

                notificationChannel.enableVibration(true);
                notificationManager.createNotificationChannel(notificationChannel);

            }
        }

        notificationManager.notify(0,builder.build());

    }
}