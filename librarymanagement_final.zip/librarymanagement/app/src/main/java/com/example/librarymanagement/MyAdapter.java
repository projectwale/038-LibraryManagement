package com.example.librarymanagement;

import static com.example.librarymanagement.LibrarianLogin.Librarian_userid;
import static com.example.librarymanagement.LibrarianLogin.Librarian_username;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.librarymanagement.ui.UpdateBook;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private List<DataClass> dataList;
    DatabaseReference databaseReference;
    public MyAdapter(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Glide.with(context).load(dataList.get(position).getBookimg()).into(holder.recImage);
        holder.recTitle.setText("Title : "+dataList.get(position).getBooktitle().toUpperCase());
        holder.recCategory.setText("Category : "+dataList.get(position).getBookcat());
        holder.recRating.setText("Rating : "+dataList.get(position).getBookrating()+" / 5");

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateBook.class);
                intent.putExtra("bookid", dataList.get(holder.getAdapterPosition()).getBookid());
                intent.putExtra("booktitle", dataList.get(holder.getAdapterPosition()).getBooktitle());
                intent.putExtra("bookcat", dataList.get(holder.getAdapterPosition()).getBookcat());
                intent.putExtra("bookrating", dataList.get(holder.getAdapterPosition()).getBookrating());
                intent.putExtra("bookdesc", dataList.get(holder.getAdapterPosition()).getBookdesc());
                intent.putExtra("bookimg", dataList.get(holder.getAdapterPosition()).getBookimg());
                intent.putExtra("uploaderid", dataList.get(holder.getAdapterPosition()).getUploaderid());
                intent.putExtra("uploader", dataList.get(holder.getAdapterPosition()).getUploader());
                intent.putExtra("documentid", dataList.get(holder.getAdapterPosition()).getDocumentid());
                context.startActivity(intent);
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Action");
                builder.setMessage("Are you sure want to delete?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String imageUrl = dataList.get(holder.getAdapterPosition()).getBookimg();
                        StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(imageUrl);
                        storageReference.delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                deleteFirebaseFromId(dataList.get(holder.getAdapterPosition()).getDocumentid());
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                            }
                        });
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        holder.recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DisplayActivity.class);
                intent.putExtra("bookid", dataList.get(holder.getAdapterPosition()).getBookid());
                intent.putExtra("booktitle", dataList.get(holder.getAdapterPosition()).getBooktitle());
                intent.putExtra("bookcat", dataList.get(holder.getAdapterPosition()).getBookcat());
                intent.putExtra("bookrating", dataList.get(holder.getAdapterPosition()).getBookrating());
                intent.putExtra("bookdesc", dataList.get(holder.getAdapterPosition()).getBookdesc());
                intent.putExtra("bookimg", dataList.get(holder.getAdapterPosition()).getBookimg());
                intent.putExtra("uploaderid", dataList.get(holder.getAdapterPosition()).getUploaderid());
                intent.putExtra("uploader", dataList.get(holder.getAdapterPosition()).getUploader());
                intent.putExtra("documentid", dataList.get(holder.getAdapterPosition()).getDocumentid());
                context.startActivity(intent);
            }
        });
    }

    private void deleteFirebaseFromId(String dockey){
        databaseReference = FirebaseDatabase.getInstance().getReference("Books").child(dockey);
        databaseReference.removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Book deleted successfully!", Snackbar.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(((Activity) context).findViewById(android.R.id.content), "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList){
        dataList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolder extends RecyclerView.ViewHolder{

    ImageView recImage,edit,delete;
    TextView recTitle,recCategory,recRating;
    CardView recCard;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recCard = itemView.findViewById(R.id.recCard);
        recTitle = itemView.findViewById(R.id.title);
        recCategory = itemView.findViewById(R.id.category);
        recRating = itemView.findViewById(R.id.rating);
        edit = itemView.findViewById(R.id.edit);
        delete = itemView.findViewById(R.id.delete);
    }
}