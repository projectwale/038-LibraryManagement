package com.example.librarymanagement;

import static com.example.librarymanagement.login.Student_email;
import static com.example.librarymanagement.login.Student_fine;
import static com.example.librarymanagement.login.Student_idcardno;
import static com.example.librarymanagement.login.Student_mobileno;
import static com.example.librarymanagement.login.Student_username;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MyIdCard extends Fragment{
    TextView ed1,ed2,ed3,ed4,ed5;
    TextView pay;
    DatabaseReference reference,databaseReference1;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_my_id_card, container, false);

        ed1 = root.findViewById(R.id.tx1);
        ed2 = root.findViewById(R.id.tx2);
        ed3 = root.findViewById(R.id.tx3);
        ed4 = root.findViewById(R.id.tx4);
        ed5 = root.findViewById(R.id.tx5);
        pay = root.findViewById(R.id.log);

        ed1.setText("Username : "+Student_username);
        ed2.setText("Email : "+Student_email);
        ed3.setText("Contact No. : "+Student_mobileno);
        ed4.setText("Library Card No. : "+Student_idcardno);
        ed5.setText("Fine : "+Student_fine);

        reference = FirebaseDatabase.getInstance().getReference("CollectedFine");
        databaseReference1 = FirebaseDatabase.getInstance().getReference("StudentData");

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Student_fine.equals("0")){
                    Snackbar.make(v, "No fine", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else{
                    Intent i = new Intent(getActivity(),Payment.class);
                    startActivity(i);
                }
            }
        });

        return root;
    }

}