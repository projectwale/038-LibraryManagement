package com.example.librarymanagement;

public class User {

    private String documentid;
    private String email;
    private String fine;
    private String library;
    private String mobile;
    private String password;
    private String token;
    private String username;

    // Getter methods
    public String getDocumentid() {
        return documentid;
    }

    public String getEmail() {
        return email;
    }
    public String getFine() {
        return fine;
    }
    public String getLibrary() {
        return library;
    }
    public String getMobile() {
        return mobile;
    }
    public String getPassword() {
        return password;
    }
    public String getToken() {
        return token;
    }
    public String getUsername() {
        return username;
    }

    // Setter methods
    public void setDocumentid(String documentid) {
        this.documentid = documentid;
    }
    // Setter methods
    public void setEmail(String email) {
        this.email = email;
    }
    // Setter methods
    public void setFine(String fine) {
        this.fine = fine;
    }
    // Setter methods
    public void setLibrary(String library) {
        this.library = library;
    }
    // Setter methods
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    // Setter methods
    public void setPassword(String password) {
        this.password = password;
    }
    // Setter methods
    public void setToken(String token) {
        this.token = token;
    }
    // Setter methods
    public void setUsername(String username) {
        this.username = username;
    }
}
