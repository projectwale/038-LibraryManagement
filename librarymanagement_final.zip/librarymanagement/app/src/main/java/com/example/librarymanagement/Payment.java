package com.example.librarymanagement;

import static com.example.librarymanagement.login.Student_email;
import static com.example.librarymanagement.login.Student_fine;
import static com.example.librarymanagement.login.Student_idcardno;
import static com.example.librarymanagement.login.Student_mobileno;
import static com.example.librarymanagement.login.Student_userid;
import static com.example.librarymanagement.login.Student_username;

import android.app.Activity;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Payment extends AppCompatActivity implements PaymentResultListener {
    TextView pay;
    TextInputLayout ti1;
    EditText ed1;
    DatabaseReference reference,databaseReference1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Payment");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        pay = findViewById(R.id.txreg);
        ti1 = findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ed1.setText(Student_fine);

        reference = FirebaseDatabase.getInstance().getReference("CollectedFine");
        databaseReference1 = FirebaseDatabase.getInstance().getReference("StudentData");

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Checkout checkout = new Checkout();
                checkout.setKeyID("rzp_test_emyQH5YEnzbX3C");
                checkout.setImage(R.drawable.priceicon);
                final Activity activity = Payment.this;
                try {
                    JSONObject options = new JSONObject();
                    options.put("name", Student_username);
                    options.put("description", "Reference No. #654321");
                    options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
                    options.put("theme.color", "#3399cc");
                    options.put("currency", "INR");
                    options.put("amount", String.valueOf(Integer.parseInt(ed1.getText().toString()) * 100));//pass amount in currency subunits
                    options.put("prefill.email", Student_email);
                    options.put("prefill.contact",Student_mobileno);
                    JSONObject retryObj = new JSONObject();
                    retryObj.put("enabled", true);
                    retryObj.put("max_count", 4);
                    options.put("retry", retryObj);

                    checkout.open(activity, options);

                } catch(Exception e) {
                    Log.e("TAG", "Error in starting Razorpay Checkout", e);
                }

            }
        });
    }

    @Override
    public void onPaymentSuccess(String s) {
        String transactionid = s;
        Map<String, Object> userData = new HashMap<>();
        userData.put("username", Student_username);
        userData.put("email", Student_email);
        userData.put("mobile", Student_mobileno);
        userData.put("library", Student_idcardno);
        userData.put("amount", ed1.getText().toString());
        userData.put("transactionid", transactionid);

        reference.push().setValue(userData);

        DatabaseReference UserRef = databaseReference1.child(Student_userid);
        UserRef.child("fine").setValue("0");

        Student_fine = "0";

        Snackbar.make(findViewById(android.R.id.content), "Your fine is clear now!", Snackbar.LENGTH_LONG).setAction("Action", null).show();

    }

    @Override
    public void onPaymentError(int i, String s) {
        Snackbar.make(findViewById(android.R.id.content), "ERROR : "+s, Snackbar.LENGTH_LONG).setAction("Action", null).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}