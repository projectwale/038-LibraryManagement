package com.example.librarymanagement.ui;

import static com.example.librarymanagement.LibrarianLogin.Librarian_userid;
import static com.example.librarymanagement.LibrarianLogin.Librarian_username;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.librarymanagement.DataClass;
import com.example.librarymanagement.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class UpdateBook extends AppCompatActivity {

    Spinner category;
    TextInputLayout id, title, pages, description;
    EditText ed1, ed2, ed3, ed4;
    TextView add, a;
    String[] categorys;
    ImageView imageView;
    private static final int CAMERA_REQUEST = 100;
    private static final int STORAGE_REQUEST = 200;
    private static final int REQUEST_GALLERY = 200;
    String cameraPermission[];
    String storagePermission[];
    String imageUrl;
    String file_path = null;
    private Uri imageUri;
    DatabaseReference databaseReference;
    StorageReference storageReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_book);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Update Book");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        categorys = getResources().getStringArray(R.array.category);
        category = findViewById(R.id.category);
        add = findViewById(R.id.add);

        id = findViewById(R.id.bookid);
        ed1 = id.getEditText();
        title = findViewById(R.id.title);
        ed2 = title.getEditText();
        pages = findViewById(R.id.nopages);
        ed3 = pages.getEditText();
        description = findViewById(R.id.description);
        ed4 = description.getEditText();
        imageView = findViewById(R.id.imageView2);
        a = findViewById(R.id.a);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(UpdateBook.this, R.layout.dropdown_item, categorys);
        category.setAdapter(adapter);

        ed1.setText(getIntent().getStringExtra("bookid"));
        ed2.setText(getIntent().getStringExtra("booktitle"));
        ed3.setText(getIntent().getStringExtra("bookrating"));
        ed4.setText(getIntent().getStringExtra("bookdesc"));
        int position = Arrays.asList(categorys).indexOf(getIntent().getStringExtra("bookcat"));
        category.setSelection(position);

        Glide.with(this)
                .load(getIntent().getStringExtra("bookimg"))
                .apply(new RequestOptions()
                        .placeholder(R.drawable.preview) // Optional placeholder image while loading
                        .error(R.drawable.preview) // Optional error image if the download fails
                        .diskCacheStrategy(DiskCacheStrategy.ALL))
                .into(imageView);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImagePicDialog();
            }
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("Books");
        storageReference = FirebaseStorage.getInstance().getReference();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String id = ed1.getText().toString();
                String title = ed2.getText().toString();
                String cat = category.getSelectedItem().toString();
                String pages = ed3.getText().toString();
                String desc = ed4.getText().toString();

                if(cat.equals("Select category") || id.equals("") || title.equals("") || pages.equals("") || desc.equals("")){
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {
                    StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(getIntent().getStringExtra("bookimg"));
                    storageReference.delete()
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    if(file_path == null){
                                        updateToFirebaseWithoutImage(id,title,cat,pages,desc,getIntent().getStringExtra("documentid"));
                                    }
                                    else {
                                        updateToFirebase(imageUri,id,title,cat,pages,desc,getIntent().getStringExtra("documentid"));
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Snackbar.make(v, "Something went wrong!", Snackbar.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });
    }

    private void updateToFirebase(Uri uri,String id,String title,String cat,String pages,String desc,String dockey){
        String timeStamp = "Image_"+new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
        final StorageReference imageReference = storageReference.child(timeStamp + "." + getFileExtension(uri));
        imageReference.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                imageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        DatabaseReference bookRef = databaseReference.child(dockey);
                        bookRef.child("bookid").setValue(id);
                        bookRef.child("booktitle").setValue(title);
                        bookRef.child("bookcat").setValue(cat);
                        bookRef.child("bookrating").setValue(pages);
                        bookRef.child("bookdesc").setValue(desc);
                        bookRef.child("uploader").setValue(Librarian_username);
                        bookRef.child("uploaderid").setValue(Librarian_userid);
                        bookRef.child("bookimg").setValue(uri.toString());

                        Snackbar.make(findViewById(android.R.id.content), "Book Updated", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Snackbar.make(findViewById(android.R.id.content),  "Something wrong!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        });
    }

    private void updateToFirebaseWithoutImage(String id,String title,String cat,String pages,String desc,String dockey){
        DatabaseReference bookRef = databaseReference.child(dockey);
        bookRef.child("bookid").setValue(id);
        bookRef.child("booktitle").setValue(title);
        bookRef.child("bookcat").setValue(cat);
        bookRef.child("bookrating").setValue(pages);
        bookRef.child("bookdesc").setValue(desc);
        bookRef.child("uploader").setValue(Librarian_username);
        bookRef.child("uploaderid").setValue(Librarian_userid);

        Snackbar.make(findViewById(android.R.id.content), "Book Updated", Snackbar.LENGTH_LONG).setAction("Action", null).show();
    }

    private String getFileExtension(Uri fileUri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(fileUri));
    }

    private void showImagePicDialog() {
        String options[] = {"Camera", "Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateBook.this);
        builder.setTitle("Pick Image From");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    if (!checkCameraPermission()) {
                        requestCameraPermission();
                    } else {
                        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_REQUEST);
                    }
                } else if (which == 1) {
                    if (!checkStoragePermission()) {
                        requestStoragePermission();
                    } else {
                        filePicker();
                    }
                }
            }
        });
        builder.create().show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_GALLERY && resultCode == Activity.RESULT_OK) {
            imageUri = data.getData();
            String filePath = getRealPathFromUri(data.getData(),this);
            Log.d("File Path : ", " " + filePath);
            this.file_path = filePath;
            File file = new File(filePath);
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(),bmOptions);
            // bitmap = Bitmap.createScaledBitmap(bitmap,parent.getWidth(),parent.getHeight(),true);
            imageView.setImageBitmap(bitmap);
        }
        else if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            file_path = "Not null";
            Bitmap theImage = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            theImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            String path = MediaStore.Images.Media.insertImage(this.getContentResolver(), theImage, "Title", null);
            imageUri = Uri.parse(path);
            imageView.setImageBitmap(theImage);
        }
    }

    public String getRealPathFromUri(Uri uri, Activity activity){
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor=activity.getContentResolver().query(uri,proj,null,null,null);
        if(cursor==null){
            return uri.getPath();
        }
        else{
            cursor.moveToFirst();
            int id=cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(id);
        }
    }
    private void filePicker(){
        Intent opengallery=new Intent(Intent.ACTION_PICK);
        opengallery.setType("image/*");
        startActivityForResult(opengallery,REQUEST_GALLERY);
    }

    private Boolean checkStoragePermission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result;
    }

    @SuppressLint("NewApi")
    private void requestStoragePermission() {
        requestPermissions(storagePermission, STORAGE_REQUEST);
    }

    private Boolean checkCameraPermission() {
        boolean result = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == (PackageManager.PERMISSION_GRANTED);
        boolean result1 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == (PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }

    @SuppressLint("NewApi")
    private void requestCameraPermission() {
        requestPermissions(cameraPermission, CAMERA_REQUEST);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
