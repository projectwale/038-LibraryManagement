package com.example.librarymanagement;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class LibrarianLogin extends AppCompatActivity {
    TextView txreg,login;
    TextInputLayout ti1,ti2;
    EditText ed1,ed2;
    FirebaseDatabase database;
    DatabaseReference reference;
    public static String Librarian_userid = "";
    public static String Librarian_username = "";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian_login);

        txreg = findViewById(R.id.newreg);
        login = findViewById(R.id.log);
        ti1 = findViewById(R.id.username1);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.password1);
        ed2 = ti2.getEditText();

        txreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LibrarianLogin.this,LibrarainRegister.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String password = ed2.getText().toString();

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("LibrarianData");

                if(username.equals("") || password.equals("")){
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {
                    reference.orderByChild("username").equalTo(username).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                    String userkey =  userSnapshot.getKey();
                                    Map<String, Object> userData = (Map<String, Object>) userSnapshot.getValue();
                                    if (userData != null && userData.containsKey("password") && userData.get("password").equals(password)) {
                                        Librarian_userid = userkey;
                                        Librarian_username = username;
                                        Intent intent = new Intent(LibrarianLogin.this, MainActivity2.class);
                                        startActivity(intent);
                                        finish(); // Optional: Close the login activity to prevent going back
                                    } else {
                                        Snackbar.make(v, "Incorrect password !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                    }
                                }
                            } else {
                                Snackbar.make(v, "Username not found !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Snackbar.make(v, "Something went wrong !", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        }
                    });
                }
            }
        });
    }
}