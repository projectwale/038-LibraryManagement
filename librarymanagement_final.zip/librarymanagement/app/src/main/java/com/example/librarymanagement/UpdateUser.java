package com.example.librarymanagement;

import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class UpdateUser extends AppCompatActivity {
    TextView reg;
    TextInputLayout ti1,ti2,ti3,ti4,ti5;
    EditText ed1,ed2,ed3,ed4,ed5;
    FirebaseDatabase database;
    DatabaseReference reference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Update User");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        reg = findViewById(R.id.txreg);
        ti1 = findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.email);
        ed2 = ti2.getEditText();
        ti3 = findViewById(R.id.mobile);
        ed3 = ti3.getEditText();
        ti4 = findViewById(R.id.password);
        ed4 = ti4.getEditText();
        ti5 = findViewById(R.id.librarycard);
        ed5 = ti5.getEditText();

        ed1.setText(getIntent().getStringExtra("username"));
        ed2.setText(getIntent().getStringExtra("email"));
        ed3.setText(getIntent().getStringExtra("mobile"));
        ed4.setText(getIntent().getStringExtra("password"));
        ed5.setText(getIntent().getStringExtra("cardno"));

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                String library = ed5.getText().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("StudentData");

                if(username.equals("") || email.equals("")|| mobile.equals("")|| password.equals("")|| library.equals("")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {
                    DatabaseReference bookRef = reference.child(getIntent().getStringExtra("docid"));
                    bookRef.child("username").setValue(username);
                    bookRef.child("email").setValue(email);
                    bookRef.child("mobile").setValue(mobile);
                    bookRef.child("password").setValue(password);
                    bookRef.child("library").setValue(library);

                    Snackbar.make(findViewById(android.R.id.content), "User Updated", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}