package com.example.librarymanagement;

import static com.example.librarymanagement.login.Student_email;
import static com.example.librarymanagement.login.Student_idcardno;
import static com.example.librarymanagement.login.Student_mobileno;
import static com.example.librarymanagement.login.Student_password;
import static com.example.librarymanagement.login.Student_userid;
import static com.example.librarymanagement.login.Student_username;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Pattern;

public class UserProfile extends Fragment {

    TextView reg;
    TextInputLayout ti1,ti2,ti3,ti4,ti5;
    EditText ed1,ed2,ed3,ed4,ed5;
    FirebaseDatabase database;
    DatabaseReference reference;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_user_profile, container, false);

        reg = root.findViewById(R.id.txreg);
        ti1 = root.findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ti2 = root.findViewById(R.id.email);
        ed2 = ti2.getEditText();
        ti3 = root.findViewById(R.id.mobile);
        ed3 = ti3.getEditText();
        ti4 = root.findViewById(R.id.password);
        ed4 = ti4.getEditText();
        ti5 = root.findViewById(R.id.librarycard);
        ed5 = ti5.getEditText();

        ed1.setText(Student_username);
        ed2.setText(Student_email);
        ed3.setText(Student_mobileno);
        ed4.setText(Student_password);
        ed5.setText(Student_idcardno);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                String library = ed5.getText().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("StudentData");

                if(username.equals("") || email.equals("")|| mobile.equals("")|| password.equals("")|| library.equals("")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {
                    DatabaseReference bookRef = reference.child(Student_userid);
                    bookRef.child("email").setValue(email);
                    bookRef.child("mobile").setValue(mobile);
                    bookRef.child("password").setValue(password);

                    Student_mobileno = mobile;
                    Student_email = email;
                    Student_password = password;

                    Snackbar.make(v, "User profile Updated", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        });

        return root;
    }
}